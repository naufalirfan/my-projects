# Forex Analysis Bot

Bot analisis forex harian dengan fitur Fundamental & Technical Analysis.

## Features

- 📊 Economic calendar dengan dampak event
- 💪 Currency strength analysis
- 📈 Technical indicators (RSI, MACD, SMA/EMA)
- 🎯 Market sentiment & trading signals
- 📱 Telegram notifications
- ⏰ Automated daily scheduling

## Installation

```bash
cd forex-bot
npm install
```

## Configuration

Edit `config.js` untuk mengatur:

```javascript
module.exports = {
  TELEGRAM_BOT_TOKEN: 'YOUR_TELEGRAM_BOT_TOKEN',
  TELEGRAM_CHAT_ID: 'YOUR_TELEGRAM_CHAT_ID',
  MAJOR_PAIRS: ['EUR/USD', 'GBP/USD', 'USD/JPY', ...],
  TECHNICAL: {
    periods: { short: 20, medium: 50, long: 200 },
    rsi: { overbought: 70, oversold: 30 }
  }
};
```

## Usage

### Run analisis sekali:
```bash
npm start
```

### Run dengan Telegram notification:
```javascript
const { analyzeForex } = require('./index');
analyzeForex(true); // true = kirim ke Telegram
```

### Run scheduled (harian jam 8 pagi):
```bash
npm run schedule
```

## Setup Telegram Bot

1. Chat @BotFather di Telegram
2. Buat bot baru: `/newbot`
3. Copy token ke `config.js`
4. Get chat ID: kirim pesan ke bot, lalu kunjungi:
   `https://api.telegram.org/bot<TOKEN>/getUpdates`
5. Copy chat ID ke `config.js`

## Technical Indicators

- **RSI (Relative Strength Index)**: Overbought (>70), Oversold (<30)
- **MACD**: Bullish/Bearish crossover
- **SMA/EMA**: Trend direction (20, 50, 200 period)
- **Moving Average Crossover**: Signal trend changes

## Output Example

```
📊 UPCOMING ECONOMIC EVENTS:
────────────────────────────────────
Wed, Jul 22  EUR  Retail Sales  High  F:1.6%  P:0.4%

💪 CURRENCY STRENGTH:
GBP: ███████ (7)
EUR: █████ (5)

📈 TECHNICAL ANALYSIS:
EUR/USD  UPTREND  RSI: 58.39  MACD: BULLISH

💡 TRADING SIGNALS:
EUR/USD  WEAK BUY (RSI: 58.39, MACD: BULLISH)

🎯 MARKET SENTIMENT:
Recommended Pair: GBP/CAD
```

## Cron Schedule

Default: `0 8 * * *` (jam 8 pagi setiap hari)

Untuk mengubah jadwal, edit `scheduler.js`:
```javascript
cron.schedule('0 8 * * *', runAnalysis, {
  timezone: 'Asia/Jakarta'
});
```

## Disclaimer

⚠️ Bot ini untuk keperluan edukasi saja. Bukan financial advice. Selalu lakukan riset sendiri sebelum trading.
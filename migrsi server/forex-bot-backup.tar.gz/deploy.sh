#!/bin/bash
# Deploy script untuk Forex Bot di Ubuntu VPS
# Usage: bash deploy.sh

set -e

echo "========================================"
echo "  FOREX BOT DEPLOYMENT - UBUNTU VPS"
echo "========================================"

# 1. Update system
echo "[1/6] Updating system packages..."
sudo apt update && sudo apt upgrade -y

# 2. Install Node.js 18+ if not installed
echo "[2/6] Installing Node.js 18..."
if ! command -v node &> /dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
  sudo apt install -y nodejs
fi
echo "Node.js $(node -v) installed"

# 3. Install PM2 globally for process management
echo "[3/6] Installing PM2..."
sudo npm install -g pm2

# 4. Install project dependencies
echo "[4/6] Installing project dependencies..."
npm install

# 5. Setup environment variables
echo "[5/6] Setting up environment..."
if [ ! -f .env ]; then
  cat > .env << 'ENVEOF'
TELEGRAM_BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID=YOUR_TELEGRAM_CHAT_ID
ENVEOF
  echo ".env file created! Edit it with your Telegram credentials:"
  echo "  nano .env"
else
  echo ".env already exists"
fi

# 6. Start with PM2
echo "[6/6] Starting bot with PM2..."
pm2 delete forex-bot 2>/dev/null || true
pm2 start scheduler.js --name "forex-bot" --cron-restart="0 0 * * *"
pm2 save
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME

echo ""
echo "========================================"
echo "  DEPLOYMENT COMPLETE!"
echo "========================================"
echo ""
echo "Commands:"
echo "  pm2 status          - Check bot status"
echo "  pm2 logs forex-bot  - View logs"
echo "  pm2 restart forex-bot - Restart"
echo "  nano .env          - Edit Telegram credentials"
echo ""
echo "Don't forget to edit your .env file!"
